# Script to brute force an md5 hash.

![md5-brute-force](https://github.com/vsevolod-mineev/md5-brute-force/blob/main/images/md5-brute-force.gif?raw=true)

This script is for brute forcing your way through an md5 hash. Install the package using `pip install`, run the script, paste your hash -> done.

# How to use:
To install `md5-brute-force` using `pip install`:
```
pip install md5-brute-force
```

To execute the script enter:
```
md5-brute-force
```
